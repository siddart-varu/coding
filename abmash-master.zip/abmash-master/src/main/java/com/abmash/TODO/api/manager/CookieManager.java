package com.abmash.TODO.api.manager;

public class CookieManager {

	public CookieManager() {
		// TODO Auto-generated constructor stub
	}

}

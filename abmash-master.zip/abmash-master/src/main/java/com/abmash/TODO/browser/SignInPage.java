package com.abmash.TODO.browser;

public class SignInPage {
	
	public SignInPage() {
		
	}

	public void loginValidUser(String username, String password) {
		
	}
}

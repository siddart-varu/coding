package com.abmash.TODO.browser.server;

public interface BrowserServer {

	public abstract void start();

	public abstract void stop();
	
}
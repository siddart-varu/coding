package com.abmash.api.data;
//package com.abmash.api.tabular;
//
//import java.util.ArrayList;
//
//public class TableRows extends ArrayList<TableRow> {
//	
//	/**
//	 * Filters and returns all rows containing the specified string.
//	 * 
//	 * @param query the string which has to be in a table cell
//	 * @return the table rows containing the query string
//	 * @see Table
//	 */
//	public TableRows filterWith(String query) {
//		TableRows filteredRows = new TableRows();
//		for (TableRow row: this) {
//			if(row.contains(query)) filteredRows.add(row);
//		}
//		return filteredRows;
//	}
//}

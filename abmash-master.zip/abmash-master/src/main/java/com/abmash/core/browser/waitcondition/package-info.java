/**
 * Provides classes to wait for certain events or conditions in order to properly react to changes (AJAX, Websockets, etc.).
 */
package com.abmash.core.browser.waitcondition;
/**
 * Provides classes to handle color queries.
 * 
 * @see com.abmash.api.query.QueryFactory#color(ColorName colorName)
 */
package com.abmash.core.color;
package com.abmash.core.document;

/**
 * Dummy interface for documents
 */
public interface Document {
	
}

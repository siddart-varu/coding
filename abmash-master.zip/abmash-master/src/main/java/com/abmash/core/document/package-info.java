/**
 * Dummy package to provide support for generic classes for different document types in the future.
 */
package com.abmash.core.document;
package com.abmash.core.element;


public abstract class Element {

	protected String id;
	
	public abstract String toString();
	
	public abstract String getText();
	
}
/**
 * Provides classes to describe certain properties of page elements.
 */
package com.abmash.core.element;